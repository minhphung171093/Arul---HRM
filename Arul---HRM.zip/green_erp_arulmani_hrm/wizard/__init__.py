# -*- encoding: utf-8 -*-

import print_payslip
import alert_form

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
