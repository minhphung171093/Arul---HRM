# -*- coding: utf-8 -*-
import hr_qualification_attachment
import hr_identities_attachment
import green_erp_arulmani_crm
import green_erp_arulmani_hr
import crm_specification
import crm_qc_test
import crm_sample_invoice
import green_erp_arulmani_sale
import crm_configuration
import wizard
import report
import print_quotation

