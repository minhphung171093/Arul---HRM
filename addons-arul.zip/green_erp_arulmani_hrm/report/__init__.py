# -*- encoding: utf-8 -*-

import arul_payslip
